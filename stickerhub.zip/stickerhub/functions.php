<?php
/**
 * STICKER HUB child theme.
 */

const SH_WHATSAPP      = '254766386934';
const SH_PHONE         = '0766 386 934';
const SH_FREE_DELIVERY = 3000; // PLACEHOLDER: free Nairobi delivery from this cart value (matches the shipping zone in setup.php).
const SH_MAPS          = 'https://www.google.com/maps/place/STICKER+HUB./@-1.2785378,36.8734679,17z/data=!4m6!3m5!1s0x182f15b8bd1424b3:0x9972d81d331a1534!8m2!3d-1.2785378!4d36.8734679';
const SH_FONTS         = 'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'sh-fonts', SH_FONTS, [], null );
	wp_enqueue_style( 'sh', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'sh', $uri . '/assets/sh.js', [], filemtime( $dir . '/assets/sh.js' ), true );
	wp_localize_script( 'sh', 'SH', [
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => SH_WHATSAPP,
		'freeAt' => SH_FREE_DELIVERY,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'sh-fonts', SH_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way shops here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function sh_wa_link( $text = '' ) {
	return 'https://wa.me/' . SH_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function sh_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

const SH_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * "Label: value" lines staff type on the product screen, as label => value pairs.
 */
function sh_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_sh_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function sh_install_steps( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_sh_install', true ) ) ) ) );
}

/** Names of the attributes a customer chooses on a variable product, e.g. [ 'Size', 'Finish' ]. */
function sh_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

function sh_badges_html( WC_Product $product ) {
	$h = '';
	if ( ! $product->is_in_stock() ) {
		$h .= '<span class="sh-badge sh-badge--out">Out of stock</span>';
	}
	return $h ? '<div class="sh-badges">' . $h . '</div>' : '';
}

/** The product a variation belongs to (or the product itself): where the unit and "From" settings live. */
function sh_parent_id( WC_Product $product ) {
	return $product->get_parent_id() ?: $product->get_id();
}

/** No price set: the shop quotes it on WhatsApp or by phone. */
function sh_on_request( WC_Product $product ) {
	return ! $product->is_type( 'variable' ) && $product->get_price() === '';
}

// "From KSh 1,200" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="sh-from">From</span> ' . wc_price( $min );
}, 10, 2 );
// "From" on simple products whose price is a starting price, and the unit after any price ("per m²").
add_filter( 'woocommerce_get_price_html', function ( $html, $product ) {
	if ( $html === '' || sh_on_request( $product ) ) {
		return $html;
	}
	$id = sh_parent_id( $product );
	if ( $product->is_type( 'simple' ) && get_post_meta( $id, '_sh_from', true ) === 'yes' ) {
		$html = '<span class="sh-from">From</span> ' . $html;
	}
	$unit = get_post_meta( $id, '_sh_unit', true );
	return $unit ? $html . ' <span class="sh-unit">' . esc_html( $unit ) . '</span>' : $html;
}, 20, 2 );
add_filter( 'woocommerce_empty_price_html', fn() => '<span class="sh-ask">Price on request</span>' );

// Send every option's price with the page (the window tint has 36), so prices change instantly when a customer
// picks options, with no server round trip (the static copy has no server to ask).
add_filter( 'woocommerce_ajax_variation_threshold', fn() => 100 );

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to cart' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p ) {
		return $t;
	}
	if ( sh_on_request( $p ) ) {
		return 'Ask for price';
	}
	if ( ! $p->is_in_stock() ) {
		return $t;
	}
	$choices = sh_choices( $p );
	return $choices ? 'Choose ' . strtolower( implode( ' & ', array_slice( $choices, 0, 2 ) ) ) : 'Add to cart';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) {
		return 'Out of stock';
	}
	return $product->managing_stock() ? 'In stock at Rabai Road' : 'Made to order · usually ready in 1–3 days';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Category badge and key specs above the options.
function sh_product_intro( WC_Product $product ) {
	$badge = get_post_meta( $product->get_id(), '_sh_badge', true );
	if ( $badge ) {
		echo '<div class="sh-tags"><span class="sh-tag">' . esc_html( $badge ) . '</span></div>';
	}
	if ( get_post_meta( $product->get_id(), '_sh_illustration', true ) === 'yes' ) {
		echo '<p class="sh-note">The picture is a drawing. WhatsApp us for photos of our real work.</p>';
	}
	$keys = array_slice( sh_specs( $product->get_id() ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="sh-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
}

// WhatsApp button ("Order" or "Ask for the price"), "Frequently paired together" and promises.
function sh_product_outro( WC_Product $product ) {
	if ( sh_on_request( $product ) ) {
		$msg = 'Hi STICKER HUB, what is the price for the ' . $product->get_name() . '? ' . $product->get_permalink();
		echo '<div class="sh-ask-box"><p>The price depends on your size and design. Send us the details and we reply with the price.</p><a class="sh-wa-ask" href="' . esc_url( sh_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . SH_WA_ICON . 'Ask for the price on WhatsApp</a><a class="sh-call" href="tel:+254766386934">Or call 0766 386 934</a></div>';
	} else {
		$price = $product->is_type( 'variable' ) ? 'from ' . sh_money( $product->get_variation_price( 'min' ) ) : sh_money( $product->get_price() );
		$msg   = 'Hi STICKER HUB, I\'d like the ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
		echo '<a class="sh-wa-order" data-sh-wa-product="' . esc_attr( $product->get_name() ) . '" data-sh-wa-price="' . esc_attr( $price ) . '" data-sh-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( sh_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . SH_WA_ICON . 'Order or send your design on WhatsApp</a>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="sh-pairs"><p class="sh-pairs__title">Frequently paired together</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_purchasable() && $p->is_in_stock()
				? '<button type="button" class="sh-pairs__add" data-sh-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to cart">+ Add</button>'
				: '<a class="sh-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="sh-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="sh-promise"><div><span aria-hidden="true">⚡</span><p><strong>Same-day Nairobi delivery</strong>Free on orders over ' . esc_html( sh_money( SH_FREE_DELIVERY ) ) . '. Upcountry courier in 1–2 days.</p></div><div><span aria-hidden="true">✎</span><p><strong>Your design, checked first</strong>Send your logo or idea on WhatsApp; we send a proof before we cut or print.</p></div><div><span aria-hidden="true">⌖</span><p><strong>Fitting at Rabai Road</strong>Bring your car or bike and we fit stickers, tints and wraps for you.</p></div></div>';
}

add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( $product instanceof WC_Product ) {
		sh_product_intro( $product );
	}
} );
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( $product instanceof WC_Product ) {
		sh_product_outro( $product );
	}
} );
// Products without a price have no add-to-cart form (and so none of its hooks): show the same blocks there.
add_action( 'woocommerce_simple_add_to_cart', function () {
	global $product;
	if ( $product instanceof WC_Product && ! $product->is_purchasable() ) {
		sh_product_intro( $product );
		sh_product_outro( $product );
	}
}, 31 );

// Details, specs & how to order, and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$id    = $product->get_id();
	$specs = sh_specs( $id );
	$steps = sh_install_steps( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'Details';
	}
	if ( $specs || $steps ) {
		$tabs['sh_specs'] = [
			'title'    => 'Specs & how to order',
			'priority' => 15,
			'callback' => function () use ( $specs, $steps ) {
				echo '<div class="sh-sheet"><div><h3>Specifications</h3><table class="sh-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div>';
				if ( $steps ) {
					echo '<div><h3>How it works</h3><ol class="sh-steps">';
					foreach ( $steps as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ol></div>';
				}
				echo '</div>';
			},
		];
	}
	$tabs['sh_delivery'] = [
		'title'    => 'Delivery & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Workshop pickup:</strong> free from Rabai Road Estate, Outer Ring Road (Mon–Sat, 8 am – 7 pm). Pay when you collect.</li><li><strong>Nairobi doorstep rider:</strong> same day for KSh 300, free on orders over ' . esc_html( sh_money( SH_FREE_DELIVERY ) ) . '. Pay the rider in cash or M-Pesa.</li><li><strong>Upcountry:</strong> courier to your county in 1–2 days for KSh 450.</li><li><strong>M-Pesa:</strong> Paybill 247247, account 0766 386 934, after we confirm your order by phone.</li><li><strong>WhatsApp orders:</strong> tap the WhatsApp button and we sort everything in the chat.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function sh_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Second photo on hover. (The heart and quick view buttons were taken off to keep the cards simple.)
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = sh_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'sh-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	return $content;
}, 10, 3 );

// Category badge above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = sh_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_sh_badge', true ) : '';
	return ( $badge ? '<p class="sh-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// "Out of stock" above the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = sh_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	return sh_badges_html( $product ) . $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function sh_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function sh_category_products( WP_Term $term ) {
	return wc_get_products( [ 'category' => [ $term->slug ], 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
}

/** Lowest price in a category, or 0 when every product there is priced on request. */
function sh_category_from( WP_Term $term ) {
	$prices = [];
	foreach ( sh_category_products( $term ) as $p ) {
		$price = $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price();
		if ( $price !== '' && $price !== null ) {
			$prices[] = (float) $price;
		}
	}
	return $prices ? min( $prices ) : 0;
}

// "Shop by category": a big picture tile per category, with its name and starting price.
add_shortcode( 'sh_services', function () {
	$h = '<div class="sh-cats">';
	foreach ( sh_categories() as $t ) {
		$thumb = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
		$from  = sh_category_from( $t );
		$h .= sprintf(
			'<a class="sh-cat" href="%s"><span class="sh-cat__img">%s</span><span class="sh-cat__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$thumb ? wp_get_attachment_image( $thumb, 'medium_large', false, [ 'loading' => 'lazy', 'alt' => '' ] ) : '',
			esc_html( $t->name ),
			$from ? 'From ' . esc_html( sh_money( $from ) ) : 'Ask for price'
		);
	}
	return $h . '</div>';
} );

function sh_chip( $label, $url, $on, $count = null ) {
	return sprintf(
		'<a class="sh-chip%s" href="%s">%s%s</a>',
		$on ? ' is-on' : '',
		esc_url( $url ),
		esc_html( $label ),
		$count === null ? '' : ' <em>' . (int) $count . '</em>'
	);
}

// Category chips above the shop, category and search pages.
add_shortcode( 'sh_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="sh-filters" aria-label="Categories"><div class="sh-filters__row">';
	$h .= sh_chip( 'Everything', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( sh_categories() as $t ) {
		$h .= sh_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	return $h . '</div></nav>';
} );

/**
 * A product's prices as [ label, price html ] rows for the price list. Choices that don't change the price
 * (a tint's shade, a panel's thickness) are left out, so each row is a real price difference.
 */
function sh_price_rows( WC_Product $p ) {
	$unit = get_post_meta( $p->get_id(), '_sh_unit', true );
	$fmt  = fn( $amount ) => esc_html( sh_money( $amount ) ) . ( $unit ? ' <small>' . esc_html( $unit ) . '</small>' : '' );
	if ( ! $p->is_type( 'variable' ) ) {
		if ( sh_on_request( $p ) ) {
			return [ [ '', '<a class="sh-ask-link" href="' . esc_url( sh_wa_link( 'Hi STICKER HUB, what is the price for the ' . $p->get_name() . '?' ) ) . '" target="_blank" rel="noopener">Ask for price</a>' ] ];
		}
		return [ [ '', ( get_post_meta( $p->get_id(), '_sh_from', true ) === 'yes' ? 'From ' : '' ) . $fmt( $p->get_price() ) ] ];
	}
	$vars = [];
	foreach ( $p->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( $v && $v->get_price() !== '' ) {
			$vars[] = [ $v->get_attributes(), (float) $v->get_price() ];
		}
	}
	foreach ( $vars ? array_keys( $vars[0][0] ) : [] as $k ) {
		$groups = [];
		foreach ( $vars as [ $a, $price ] ) {
			unset( $a[ $k ] );
			$groups[ serialize( $a ) ][ (string) $price ] = true;
		}
		if ( max( array_map( 'count', $groups ) ) === 1 ) {
			foreach ( $vars as $i => $row ) {
				unset( $vars[ $i ][0][ $k ] );
			}
		}
	}
	$rows = [];
	foreach ( $vars as [ $a, $price ] ) {
		$rows[ implode( ' · ', $a ) ] = $price;
	}
	return array_map( fn( $label, $price ) => [ $label, $fmt( $price ) ], array_keys( $rows ), $rows );
}

// Every price on one page, by category.
add_shortcode( 'sh_price_list', function () {
	$cats = sh_categories();
	$h    = '<nav class="sh-filters" aria-label="Jump to a category"><div class="sh-filters__row">';
	foreach ( $cats as $t ) {
		$h .= sh_chip( $t->name, '#prices-' . $t->slug, false );
	}
	$h .= '</div></nav><div class="sh-prices">';
	foreach ( $cats as $t ) {
		$h .= '<section class="sh-prices__cat" id="prices-' . esc_attr( $t->slug ) . '"><h2><a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a></h2><table class="sh-prices__table"><tbody>';
		foreach ( sh_category_products( $t ) as $p ) {
			foreach ( sh_price_rows( $p ) as $i => [ $label, $price ] ) {
				$name = $i ? '' : '<a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a>';
				$h .= '<tr' . ( $i ? ' class="is-more"' : '' ) . '><th>' . $name . ( $label !== '' ? '<span>' . esc_html( $label ) . '</span>' : '' ) . '</th><td>' . $price . '</td></tr>';
			}
		}
		$h .= '</tbody></table></section>';
	}
	return $h . '</div>';
} );

// Real Google reviews (checked on the listing, October 2026). Only reviews with text are quoted.
add_shortcode( 'sh_reviews', function () {
	$reviews = [
		[ 'Ferdinard Onyango', 5, 'Quick services and quality stuff', '7 months ago' ],
		[ 'Lewis Muturi', 4, 'It\'s the best place to get your car pimped. Business logo and many more.', '2 years ago' ],
	];
	$stars = fn( $n ) => '<span class="sh-stars" aria-label="' . $n . ' out of 5 stars">' . str_repeat( '★', $n ) . '<span>' . str_repeat( '★', 5 - $n ) . '</span></span>';
	$h = '<div class="sh-reviews"><a class="sh-reviews__score" href="' . esc_url( SH_MAPS ) . '" target="_blank" rel="noopener"><strong>4.7</strong>' . $stars( 5 ) . '<span>19 Google ratings</span><em>Read on Google Maps →</em></a><div class="sh-reviews__list" data-sh-carousel>';
	foreach ( $reviews as [ $name, $n, $text, $when ] ) {
		$h .= '<figure class="sh-review">' . $stars( $n ) . '<blockquote>“' . esc_html( $text ) . '”</blockquote><figcaption><strong>' . esc_html( $name ) . '</strong><span>Google review · ' . esc_html( $when ) . '</span></figcaption></figure>';
	}
	return $h . '</div></div>';
} );

// Price calculator: the price of a banner, stickers or vinyl from its size. The rates are read from the products
// (variation prices), so changing a price in the admin changes the calculator too; sh.js does the maths.
add_shortcode( 'sh_estimator', function () {
	$types = [
		'print'   => [ 'Banner or large print', 'Priced per square metre', 'large-format-printing' ],
		'sticker' => [ 'Stickers & labels', 'Priced per square metre', 'printed-stickers-labels' ],
		'vinyl'   => [ 'Vinyl by the metre', 'For your own projects', 'vinyl-by-the-metre' ],
	];
	$calc = [];
	foreach ( $types as $type => [ $name, , $slug ] ) {
		$post = get_page_by_path( $slug, OBJECT, 'product' );
		$p    = $post ? wc_get_product( $post->ID ) : null;
		if ( ! $p || ! $p->is_type( 'variable' ) ) {
			continue;
		}
		$prices = [];
		foreach ( $p->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && $v->get_price() !== '' ) {
				$prices[ (string) current( $v->get_attributes() ) ] = (float) $v->get_price();
			}
		}
		$calc[ $type ] = [ 'name' => $name, 'url' => $p->get_permalink(), 'prices' => $prices ];
	}
	if ( ! $calc ) {
		return '';
	}
	$shown = fn( $type ) => $type === array_key_first( $calc ) ? '' : ' hidden';
	$num = fn( $name, $label, $value, $step = '1', $min = '1' ) => '<label>' . esc_html( $label ) . '<input type="number" name="' . $name . '" min="' . $min . '" step="' . $step . '" value="' . $value . '" inputmode="decimal"></label>';

	ob_start();
	?>
	<form class="sh-est" data-sh-estimator data-calc="<?php echo esc_attr( wp_json_encode( $calc ) ); ?>" novalidate>
		<ol class="sh-est__steps" aria-hidden="true"><li class="is-on">What</li><li>Material</li><li>Size</li></ol>

		<fieldset class="sh-est__step" data-step="1">
			<legend><span>1</span> What do you need?</legend>
			<div class="sh-est__types">
				<?php $first = true; foreach ( $calc as $type => $c ) : ?>
					<label><input type="radio" name="type" value="<?php echo esc_attr( $type ); ?>"<?php echo $first ? ' checked' : ''; ?>><strong><?php echo esc_html( $c['name'] ); ?></strong><em><?php echo esc_html( $types[ $type ][1] ); ?></em></label>
				<?php $first = false; endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="sh-est__step" data-step="2">
			<legend><span>2</span> Which material?</legend>
			<?php foreach ( $calc as $type => $c ) : ?>
				<div class="sh-est__grid" data-for="<?php echo esc_attr( $type ); ?>"<?php echo $shown( $type ); ?>>
					<label>Material<select name="mat_<?php echo esc_attr( $type ); ?>">
						<?php foreach ( $c['prices'] as $label => $price ) : ?>
							<option value="<?php echo esc_attr( $label ); ?>"><?php echo esc_html( $label . ' – ' . sh_money( $price ) . ( $type === 'vinyl' ? ' per metre' : ' per m²' ) ); ?></option>
						<?php endforeach; ?>
					</select></label>
				</div>
			<?php endforeach; ?>
		</fieldset>

		<fieldset class="sh-est__step" data-step="3">
			<legend><span>3</span> What size?</legend>
			<div class="sh-est__grid" data-for="print"><?php echo $num( 'w', 'Width (metres)', '2', '0.1', '0.1' ) . $num( 'h', 'Height (metres)', '1', '0.1', '0.1' ) . $num( 'n', 'Copies', '1' ); ?></div>
			<div class="sh-est__grid" data-for="sticker"<?php echo $shown( 'sticker' ); ?>><?php echo $num( 'sw', 'Sticker width (cm)', '10' ) . $num( 'sh', 'Sticker height (cm)', '10' ) . $num( 'sn', 'How many stickers', '100' ); ?></div>
			<div class="sh-est__grid" data-for="vinyl"<?php echo $shown( 'vinyl' ); ?>><?php echo $num( 'm', 'Metres', '5', '0.5', '0.5' ); ?></div>
		</fieldset>

		<div class="sh-est__result" aria-live="polite">
			<div>
				<p class="sh-est__label">Price</p>
				<p class="sh-est__total" data-sh-est-total>KSh 0</p>
				<p class="sh-est__summary" data-sh-est-summary></p>
				<p class="sh-small">Worked out from our price list. We confirm the final price when we see your design.</p>
			</div>
			<div class="sh-est__actions">
				<a class="wp-element-button" data-sh-est-order href="<?php echo esc_url( current( $calc )['url'] ); ?>">Order this</a>
				<a class="sh-wa-order sh-est__wa" data-sh-est-wa href="<?php echo esc_url( sh_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo SH_WA_ICON; ?>Send to us on WhatsApp</a>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<a class="sh-wa-float" href="' . esc_url( sh_wa_link( 'Hi STICKER HUB, I have a design / project idea:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with STICKER HUB on WhatsApp">' . SH_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function sh_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, SH_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / SH_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . sh_money( $left ) . '</strong> more for <strong>free Nairobi express delivery!</strong>'
		: '<strong>You\'ve unlocked free Nairobi express delivery!</strong>';
	return '<div class="sh-freebar" data-sh-freebar>' . $msg . '<div class="sh-freebar__track"><div class="sh-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function sh_cart_note_html() {
	return '<div class="sh-cart-note"><strong>Custom work?</strong> After you order, send your logo or design on WhatsApp. We send a proof before we cut or print.</div>';
}
function sh_wa_cart_html() {
	return '<button type="button" class="sh-wa-cart" data-sh-wa-cart>Send this order to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => sh_freebar_html() . sh_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . sh_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', sh_freebar_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="sh-wa-cart-wrap">' . sh_wa_cart_html() . '</div>' );

// Payment follows delivery: "Pay at the workshop" only for pickup, cash on delivery only for riders and couriers.
add_filter( 'woocommerce_available_payment_gateways', function ( $gateways ) {
	if ( is_admin() && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return $gateways;
	}
	$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods', [] ) : [];
	$pickup = $chosen && array_intersect( $chosen, (array) get_option( 'sh_pickup_rates', [] ) );
	unset( $gateways[ $pickup ? 'cod' : 'cheque' ] );
	return $gateways;
} );

// Once free Nairobi delivery applies, don't also offer the paid rider.
add_filter( 'woocommerce_package_rates', function ( $rates ) {
	$free = array_filter( $rates, fn( $r ) => $r->get_method_id() === 'free_shipping' );
	if ( $free ) {
		$rates = array_filter( $rates, fn( $r ) => ! ( $r->get_method_id() === 'flat_rate' && (float) $r->get_cost() > 0 ) );
	}
	return $rates;
} );

// A retried checkout (customer went back and changed delivery) must replace the old shipping line. WooCommerce
// clears it with a DELETE … USING query that the SQLite database of the Playground demo silently skips, so the
// order kept the old method. Make sure the saved shipping line matches the customer's choice.
add_action( 'woocommerce_store_api_checkout_order_processed', function ( $order ) {
	$chosen = WC()->session ? array_values( (array) WC()->session->get( 'chosen_shipping_methods', [] ) ) : [];
	if ( ! $chosen || ! WC()->cart || ! WC()->cart->needs_shipping() ) {
		return;
	}
	$have = array_values( array_map( fn( $m ) => $m->get_name(), $order->get_shipping_methods() ) );
	$want = [];
	foreach ( WC()->shipping()->get_packages() as $i => $pkg ) {
		if ( isset( $pkg['rates'][ $chosen[ $i ] ?? '' ] ) ) {
			$want[] = $pkg['rates'][ $chosen[ $i ] ]->get_label();
		}
	}
	if ( $want && $have !== $want ) {
		// One item at a time: remove_order_items() is the query the demo's SQLite layer skips.
		foreach ( array_keys( $order->get_shipping_methods() ) as $item_id ) {
			$order->remove_item( $item_id );
		}
		WC()->checkout()->create_order_shipping_lines( $order, $chosen, WC()->shipping()->get_packages() );
		$order->calculate_totals();
		$order->save();
	}
}, 1 );

// A landmark helps the rider find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'sh/landmark',
		'label'    => 'Building, estate or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Order number and WhatsApp summary on the order confirmation page.
function sh_tracking_code( WC_Order $order ) {
	return 'SH-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function sh_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi STICKER HUB, I just placed order ' . sh_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$meta = [];
		foreach ( $item->get_formatted_meta_data() as $m ) {
			$meta[] = wp_strip_all_tags( $m->display_value );
		}
		$lines[] = '• ' . $item->get_name() . ( $meta && ! $item->get_variation_id() ? ' (' . implode( ', ', $meta ) . ')' : '' ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . sh_money( $item->get_total() );
	}
	$lines[] = 'Delivery: ' . $order->get_shipping_method() . ( (float) $order->get_shipping_total() > 0 ? ' (' . sh_money( $order->get_shipping_total() ) . ')' : '' );
	$lines[] = 'Total: ' . sh_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address && stripos( $order->get_shipping_method(), 'pick up' ) === false ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	$lines[] = 'I\'ll send my design / logo here.';
	return sh_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="sh-thanks"><p class="sh-thanks__code">Order number <strong>' . esc_html( sh_tracking_code( $order ) ) . '</strong></p><p>We\'ll call you shortly to confirm. Send your order to our WhatsApp now, with your logo or design files, so we can start on your proof.</p><a class="wp-element-button sh-wa-btn" href="' . esc_attr( sh_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order to WhatsApp (+254 766 386 934)</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( sh_tracking_code( $order ) ) . '</p>';
} );

// Staff edit the badge, durability tag, spec sheet and fitting steps on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_sh_badge', 'label' => 'Category badge', 'description' => 'Shown above the name, e.g. "Automotive Vinyl".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_sh_unit', 'label' => 'Price unit', 'description' => 'Shown after the price, e.g. "per m²", "per metre", "per piece". Leave empty for none.', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_sh_from', 'label' => 'Starting price', 'description' => 'Show "From" before the price (the final price depends on size).' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sh_specs', 'label' => 'Specifications', 'rows' => 6, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sh_install', 'label' => 'Surface prep & application', 'rows' => 6, 'description' => 'One step per line.' ] );
	echo '<p class="form-field"><em>Options: add Size (or Material, Vehicle…) under Attributes, then create a variation for each combination with its price. Leave the price empty to show "Price on request" with an "Ask for the price" WhatsApp button. "Frequently paired together" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	$product->update_meta_data( '_sh_from', isset( $_POST['_sh_from'] ) ? 'yes' : 'no' );
	foreach ( [ '_sh_badge', '_sh_unit' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
	foreach ( [ '_sh_specs', '_sh_install' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. Buruburu, Westlands, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0D0D0F\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// estimator's and reviews' grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
