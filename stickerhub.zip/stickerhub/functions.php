<?php
/**
 * STICKER HUB child theme.
 */

const SH_WHATSAPP      = '254766386934';
const SH_PHONE         = '0766 386 934';
const SH_FREE_DELIVERY = 3000; // PLACEHOLDER: free Nairobi delivery from this cart value (matches the shipping zone in setup.php).
const SH_MAPS          = 'https://www.google.com/maps/place/STICKER+HUB./@-1.2785378,36.8734679,17z/data=!4m6!3m5!1s0x182f15b8bd1424b3:0x9972d81d331a1534!8m2!3d-1.2785378!4d36.8734679';
const SH_FONTS         = 'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap';

// PLACEHOLDER estimator rates, to confirm with the client. Prices in KSh.
const SH_ESTIMATOR = [
	'wrap'   => [
		'vehicles' => [ 'saloon' => 'Saloon / hatchback', 'suv' => 'SUV / pickup', 'van' => 'Van / matatu' ],
		'areas'    => [
			'bonnet'      => [ 'Bonnet', [ 'saloon' => 8500, 'suv' => 10000, 'van' => 12000 ] ],
			'roof'        => [ 'Roof', [ 'saloon' => 9000, 'suv' => 11000, 'van' => 14000 ] ],
			'bonnet-roof' => [ 'Bonnet + roof', [ 'saloon' => 17000, 'suv' => 20000, 'van' => 25000 ] ],
			'mirrors'     => [ 'Mirrors + trims', [ 'saloon' => 3500, 'suv' => 4000, 'van' => 4500 ] ],
			'full'        => [ 'Full colour change', [ 'saloon' => 65000, 'suv' => 85000, 'van' => 110000 ] ],
		],
		'finishes' => [ 'gloss' => 1, 'matte' => 1.1, 'carbon-fibre' => 1.25, 'chameleon' => 1.4, 'reflective' => 1.3, 'holographic' => 1.3 ],
	],
	'decal'  => [
		'per_m2'   => 3500,
		'min'      => 500,
		'finishes' => [ 'gloss' => 1, 'matte' => 1, 'reflective' => 1.3, 'holographic' => 1.3, 'carbon-fibre' => 1.2 ],
		'bulk'     => [ 10 => 0.1, 50 => 0.2 ], // quantity => discount
	],
	'tint'   => [
		'lights' => [ 'headlights' => [ 'Headlights (pair)', 3500 ], 'taillights' => [ 'Taillights (pair)', 3000 ], 'both' => [ 'Headlights + taillights', 6000 ], 'fog' => [ 'Fog lights (pair)', 2000 ] ],
		'shades' => [ 'smoked' => 'Light smoke', 'dark' => 'Dark smoke', 'yellow' => 'Yellow' ],
	],
	'tshirt' => [
		'tiers' => [ 1 => 1200, 10 => 950, 50 => 800 ], // from this many shirts => price each, front print
		'back'  => [ 1 => 500, 10 => 400, 50 => 300 ],  // extra for a back print
	],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'sh-fonts', SH_FONTS, [], null );
	wp_enqueue_style( 'sh', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'sh', $uri . '/assets/sh.js', [], filemtime( $dir . '/assets/sh.js' ), true );
	wp_localize_script( 'sh', 'SH', [
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => SH_WHATSAPP,
		'freeAt' => SH_FREE_DELIVERY,
		'est'    => SH_ESTIMATOR,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'sh-fonts', SH_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Finish pages (/finish/holographic/) need rewrite rules made after the attribute exists.
add_action( 'init', function () {
	if ( get_option( 'sh_rewrites' ) !== '1' && taxonomy_exists( 'pa_finish' ) ) {
		flush_rewrite_rules();
		update_option( 'sh_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way shops here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function sh_wa_link( $text = '' ) {
	return 'https://wa.me/' . SH_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function sh_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

const SH_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * "Label: value" lines staff type on the product screen, as label => value pairs.
 */
function sh_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_sh_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function sh_install_steps( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_sh_install', true ) ) ) ) );
}

/** Names of the attributes a customer chooses on a variable product, e.g. [ 'Size', 'Finish' ]. */
function sh_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/** The product's finishes, as term objects. */
function sh_finishes_of( WC_Product $product ) {
	$terms = taxonomy_exists( 'pa_finish' ) ? wc_get_product_terms( $product->get_id(), 'pa_finish', [ 'fields' => 'all' ] ) : [];
	return is_wp_error( $terms ) ? [] : $terms;
}

// Swatch colour for a finish, used on cards, chips and the finish buttons on product pages.
function sh_finish_css( $slug ) {
	return [
		'gloss'        => 'linear-gradient(135deg,#ffffff 0%,#cbd5e1 45%,#ffffff 55%,#94a3b8 100%)',
		'matte'        => '#4b5563',
		'reflective'   => 'repeating-linear-gradient(45deg,#e2e8f0 0 3px,#94a3b8 3px 6px)',
		'holographic'  => 'conic-gradient(from 30deg,#f472b6,#fbbf24,#34d399,#60a5fa,#a78bfa,#f472b6)',
		'carbon-fibre' => 'repeating-linear-gradient(45deg,#111 0 3px,#2d2d33 3px 6px)',
		'chameleon'    => 'linear-gradient(135deg,#22c55e,#eab308 50%,#a855f7)',
		'smoked'       => 'linear-gradient(135deg,#52525b,#09090b)',
	][ $slug ] ?? '#444';
}

function sh_finish_dots_html( WC_Product $product ) {
	$terms = sh_finishes_of( $product );
	if ( ! $terms ) {
		return '';
	}
	$h = '<div class="sh-swatches" aria-label="Finishes">';
	foreach ( $terms as $t ) {
		$h .= '<span class="sh-swatch" style="background:' . esc_attr( sh_finish_css( $t->slug ) ) . '" title="' . esc_attr( $t->name ) . '"></span>';
	}
	return $h . '<em>' . esc_html( implode( ' · ', wp_list_pluck( $terms, 'name' ) ) ) . '</em></div>';
}

function sh_badges_html( WC_Product $product ) {
	$h = '';
	if ( ! $product->is_in_stock() ) {
		$h .= '<span class="sh-badge sh-badge--out">Out of stock</span>';
	}
	$life = get_post_meta( $product->get_id(), '_sh_life', true );
	if ( $life ) {
		$h .= '<span class="sh-badge sh-badge--life">' . esc_html( $life ) . '</span>';
	}
	return $h ? '<div class="sh-badges">' . $h . '</div>' : '';
}

// "From KSh 1,200" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="sh-from">From</span> ' . wc_price( $min );
}, 10, 2 );

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to cart' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	$choices = sh_choices( $p );
	return $choices ? 'Choose ' . strtolower( implode( ' & ', array_slice( $choices, 0, 2 ) ) ) : 'Add to cart';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) {
		return 'Out of stock';
	}
	return $product->managing_stock() ? 'In stock at Rabai Road' : 'Made to order · usually ready in 1–3 days';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Category badge, durability tag and key specs above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$badge = get_post_meta( $product->get_id(), '_sh_badge', true );
	$life  = get_post_meta( $product->get_id(), '_sh_life', true );
	echo '<div class="sh-tags">' . ( $badge ? '<span class="sh-tag">' . esc_html( $badge ) . '</span>' : '' ) . ( $life ? '<span class="sh-tag sh-tag--life">' . esc_html( $life ) . '</span>' : '' ) . '</div>';
	if ( get_post_meta( $product->get_id(), '_sh_illustration', true ) === 'yes' ) {
		echo '<p class="sh-note">The pictures are illustrations. WhatsApp us for photos of our real work.</p>';
	}
	$keys = array_slice( sh_specs( $product->get_id() ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="sh-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Order on WhatsApp, "Frequently paired together" and promises under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . sh_money( $product->get_variation_price( 'min' ) ) : sh_money( $product->get_price() );
	$msg   = 'Hi STICKER HUB, I\'d like the ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="sh-wa-order" data-sh-wa-product="' . esc_attr( $product->get_name() ) . '" data-sh-wa-price="' . esc_attr( $price ) . '" data-sh-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( sh_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . SH_WA_ICON . 'Order or send your design on WhatsApp</a>';

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="sh-pairs"><p class="sh-pairs__title">Frequently paired together</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="sh-pairs__add" data-sh-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to cart">+ Add</button>'
				: '<a class="sh-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="sh-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="sh-promise"><div><span aria-hidden="true">⚡</span><p><strong>Same-day Nairobi delivery</strong>Free on orders over ' . esc_html( sh_money( SH_FREE_DELIVERY ) ) . '. Upcountry courier in 1–2 days.</p></div><div><span aria-hidden="true">✎</span><p><strong>Your design, checked first</strong>Send your logo or idea on WhatsApp; we send a proof before we cut or print.</p></div><div><span aria-hidden="true">⌖</span><p><strong>Fitting at Rabai Road</strong>Bring your car or bike and we fit decals, wraps and tints for you.</p></div></div>';
} );

// Details, application & spec sheet, and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$id    = $product->get_id();
	$specs = sh_specs( $id );
	$steps = sh_install_steps( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'Details';
	}
	if ( $specs || $steps ) {
		$tabs['sh_specs'] = [
			'title'    => 'Application & spec sheet',
			'priority' => 15,
			'callback' => function () use ( $specs, $steps, $product ) {
				$finishes = sh_finishes_of( $product );
				echo '<div class="sh-sheet"><div><h3>Specifications</h3><table class="sh-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				if ( $finishes ) {
					echo '<tr><th>Finishes</th><td>' . esc_html( implode( ', ', wp_list_pluck( $finishes, 'name' ) ) ) . '</td></tr>';
				}
				echo '</tbody></table></div>';
				if ( $steps ) {
					echo '<div><h3>Surface prep & application</h3><ol class="sh-steps">';
					foreach ( $steps as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ol><p class="sh-small">Durability figures are typical for the material in Nairobi sun and depend on surface, care and washing.</p></div>';
				}
				echo '</div>';
			},
		];
	}
	$tabs['sh_delivery'] = [
		'title'    => 'Delivery & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Workshop pickup:</strong> free from Rabai Road Estate, Outer Ring Road (Mon–Sat, 8 am – 7 pm). Pay when you collect.</li><li><strong>Nairobi doorstep rider:</strong> same day for KSh 300, free on orders over ' . esc_html( sh_money( SH_FREE_DELIVERY ) ) . '. Pay the rider in cash or M-Pesa.</li><li><strong>Upcountry:</strong> courier to your county in 1–2 days for KSh 450.</li><li><strong>M-Pesa:</strong> Paybill 247247, account 0766 386 934, after we confirm your order by phone.</li><li><strong>WhatsApp orders:</strong> tap the WhatsApp button and we sort everything in the chat.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function sh_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const SH_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = sh_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'sh-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$extra = sprintf(
		'<button type="button" class="sh-heart" data-sh-wish="%1$d" aria-label="Save %2$s to your wishlist" aria-pressed="false">%3$s</button><button type="button" class="sh-qv-btn" data-sh-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		SH_HEART
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Category badge above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = sh_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_sh_badge', true ) : '';
	return ( $badge ? '<p class="sh-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Finish swatches and the durability tag around the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = sh_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	return sh_finish_dots_html( $product ) . sh_badges_html( $product ) . $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function sh_categories( $with_tools = true ) {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	$terms = is_wp_error( $terms ) ? [] : $terms;
	return $with_tools ? $terms : array_values( array_filter( $terms, fn( $t ) => $t->slug !== 'tools-care' ) );
}

// "Shop by service": one tile per category, with a photo of its first product not already used by an earlier tile.
add_shortcode( 'sh_services', function () {
	$h    = '<div class="sh-services">';
	$used = [];
	$sub  = [
		'vinyl-decals'    => 'Die-cut · Holographic · 3D dome',
		'car-wraps'       => 'Full & partial wraps · Banners · Fleet',
		'tints'           => 'Headlight · Taillight · Chameleon',
		'tshirt-printing' => 'One shirt to a full batch',
		'large-format'    => 'Business cards · Flyers · Certificates · Banners',
	];
	foreach ( sh_categories( false ) as $t ) {
		$list  = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 10, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		$pick  = current( array_filter( $list, fn( $p ) => ! in_array( $p->get_id(), $used, true ) ) ) ?: ( $list[0] ?? null );
		$used[] = $pick ? $pick->get_id() : 0;
		$img   = $pick ? $pick->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h .= sprintf(
			'<a class="sh-service" href="%s"><span class="sh-service__img">%s</span><span class="sh-service__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? sprintf( _n( '%d product', '%d products', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

function sh_finish_terms() {
	if ( ! taxonomy_exists( 'pa_finish' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_finish', 'hide_empty' => true, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function sh_chip( $label, $url, $on, $count = null, $small = false, $swatch = '' ) {
	return sprintf(
		'<a class="sh-chip%s%s" href="%s">%s%s%s</a>',
		$small ? ' sh-chip--sm' : '',
		$on ? ' is-on' : '',
		esc_url( $url ),
		$swatch ? '<i style="background:' . esc_attr( $swatch ) . '"></i>' : '',
		esc_html( $label ),
		$count === null ? '' : ' <em>' . (int) $count . '</em>'
	);
}

// Quick finish filter bar for the home page.
add_shortcode( 'sh_finish_bar', function () {
	$h = '<div class="sh-finish-bar"><span>Shop by finish</span>';
	foreach ( sh_finish_terms() as $t ) {
		$h .= sh_chip( $t->name, get_term_link( $t ), false, null, false, sh_finish_css( $t->slug ) );
	}
	return $h . '</div>';
} );

// Service and finish chips above shop, category, finish and search pages.
add_shortcode( 'sh_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="sh-filters" aria-label="Filter products"><div class="sh-filters__row">';
	$h .= sh_chip( 'Everything', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( sh_categories() as $t ) {
		$h .= sh_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="sh-filters__row"><span>Finish</span>';
	foreach ( sh_finish_terms() as $t ) {
		$h .= sh_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true, sh_finish_css( $t->slug ) );
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'sh_wishlist', function () {
	return '<div class="sh-wishlist" data-sh-wishlist><p class="sh-small">Loading your saved items…</p></div>';
} );

// Real Google reviews (checked on the listing, October 2026). Only reviews with text are quoted.
add_shortcode( 'sh_reviews', function () {
	$reviews = [
		[ 'Ferdinard Onyango', 5, 'Quick services and quality stuff', '7 months ago' ],
		[ 'Lewis Muturi', 4, 'It\'s the best place to get your car pimped. Business logo and many more.', '2 years ago' ],
	];
	$stars = fn( $n ) => '<span class="sh-stars" aria-label="' . $n . ' out of 5 stars">' . str_repeat( '★', $n ) . '<span>' . str_repeat( '★', 5 - $n ) . '</span></span>';
	$h = '<div class="sh-reviews"><a class="sh-reviews__score" href="' . esc_url( SH_MAPS ) . '" target="_blank" rel="noopener"><strong>4.7</strong>' . $stars( 5 ) . '<span>19 Google ratings</span><em>Read on Google Maps →</em></a><div class="sh-reviews__list" data-sh-carousel>';
	foreach ( $reviews as [ $name, $n, $text, $when ] ) {
		$h .= '<figure class="sh-review">' . $stars( $n ) . '<blockquote>“' . esc_html( $text ) . '”</blockquote><figcaption><strong>' . esc_html( $name ) . '</strong><span>Google review · ' . esc_html( $when ) . '</span></figcaption></figure>';
	}
	return $h . '</div></div>';
} );

// Custom decal & wrap cost estimator. The rates are in SH_ESTIMATOR; sh.js does the maths and the WhatsApp message.
add_shortcode( 'sh_estimator', function () {
	$wrap  = SH_ESTIMATOR['wrap'];
	$tint  = SH_ESTIMATOR['tint'];
	$names = [ 'gloss' => 'Standard gloss', 'matte' => 'Matte', 'reflective' => 'Reflective', 'carbon-fibre' => 'Carbon fibre', 'chameleon' => 'Chameleon', 'holographic' => 'Holographic' ];
	$opt   = fn( $v, $label, $on = false ) => '<option value="' . esc_attr( $v ) . '"' . ( $on ? ' selected' : '' ) . '>' . esc_html( $label ) . '</option>';
	$finish_btns = function ( array $keys, $group ) use ( $names ) {
		$h = '';
		foreach ( $keys as $i => $k ) {
			$h .= '<label class="sh-fin"><input type="radio" name="finish_' . $group . '" value="' . esc_attr( $k ) . '"' . ( $i ? '' : ' checked' ) . '><i style="background:' . esc_attr( sh_finish_css( $k ) ) . '"></i><span>' . esc_html( $names[ $k ] ) . '</span></label>';
		}
		return $h;
	};

	ob_start();
	?>
	<form class="sh-est" data-sh-estimator novalidate>
		<ol class="sh-est__steps" aria-hidden="true"><li class="is-on">Project</li><li>Size</li><li>Finish</li></ol>

		<fieldset class="sh-est__step" data-step="1">
			<legend><span>1</span> What are we making?</legend>
			<div class="sh-est__types">
				<label><input type="radio" name="type" value="wrap" checked><strong>Vehicle wrap</strong><em>Bonnet, roof, trims or full colour change</em></label>
				<label><input type="radio" name="type" value="decal"><strong>Custom decal</strong><em>Names, logos, portraits, stickers</em></label>
				<label><input type="radio" name="type" value="tint"><strong>Headlight tint</strong><em>Head, tail and fog lights</em></label>
				<label><input type="radio" name="type" value="tshirt"><strong>T-shirt batch</strong><em>Your design on cotton tees</em></label>
			</div>
		</fieldset>

		<fieldset class="sh-est__step" data-step="2">
			<legend><span>2</span> Size, coverage or quantity</legend>
			<div class="sh-est__grid" data-for="wrap">
				<label>Vehicle<select name="vehicle"><?php foreach ( $wrap['vehicles'] as $k => $v ) echo $opt( $k, $v ); ?></select></label>
				<label>Coverage<select name="area"><?php foreach ( $wrap['areas'] as $k => [ $v ] ) echo $opt( $k, $v, $k === 'bonnet' ); ?></select></label>
			</div>
			<div class="sh-est__grid" data-for="decal" hidden>
				<label>Width (cm)<input type="number" name="w" min="5" max="500" value="30" inputmode="numeric"></label>
				<label>Height (cm)<input type="number" name="h" min="5" max="300" value="20" inputmode="numeric"></label>
				<label>Quantity<input type="number" name="qty" min="1" max="1000" value="1" inputmode="numeric"></label>
			</div>
			<div class="sh-est__grid" data-for="tint" hidden>
				<label>Lights<select name="lights"><?php foreach ( $tint['lights'] as $k => [ $v ] ) echo $opt( $k, $v ); ?></select></label>
			</div>
			<div class="sh-est__grid" data-for="tshirt" hidden>
				<label>Number of shirts<input type="number" name="shirts" min="1" max="2000" value="10" inputmode="numeric"></label>
				<label>Print<select name="sides"><?php echo $opt( 'front', 'Front only' ) . $opt( 'both', 'Front + back' ); ?></select></label>
			</div>
		</fieldset>

		<fieldset class="sh-est__step" data-step="3">
			<legend><span>3</span> Material finish</legend>
			<div class="sh-est__fins" data-for="wrap"><?php echo $finish_btns( array_keys( $wrap['finishes'] ), 'wrap' ); ?></div>
			<div class="sh-est__fins" data-for="decal" hidden><?php echo $finish_btns( array_keys( SH_ESTIMATOR['decal']['finishes'] ), 'decal' ); ?></div>
			<div class="sh-est__fins" data-for="tint" hidden>
				<?php foreach ( array_keys( $tint['shades'] ) as $i => $k ) : ?>
					<label class="sh-fin"><input type="radio" name="shade" value="<?php echo esc_attr( $k ); ?>"<?php echo $i ? '' : ' checked'; ?>><i style="background:<?php echo esc_attr( $k === 'yellow' ? 'linear-gradient(135deg,#fde68a,#f59e0b)' : ( $k === 'dark' ? '#18181b' : sh_finish_css( 'smoked' ) ) ); ?>"></i><span><?php echo esc_html( $tint['shades'][ $k ] ); ?></span></label>
				<?php endforeach; ?>
			</div>
			<div class="sh-est__fins" data-for="tshirt" hidden>
				<label class="sh-fin"><input type="radio" name="tee" value="Black" checked><i style="background:#111"></i><span>Black shirts</span></label>
				<label class="sh-fin"><input type="radio" name="tee" value="White"><i style="background:#f8fafc"></i><span>White shirts</span></label>
				<label class="sh-fin"><input type="radio" name="tee" value="Other colour"><i style="background:conic-gradient(#ef4444,#f59e0b,#22c55e,#3b82f6,#a855f7,#ef4444)"></i><span>Other colour</span></label>
			</div>
		</fieldset>

		<div class="sh-est__result" aria-live="polite">
			<div>
				<p class="sh-est__label">Instant estimate</p>
				<p class="sh-est__total" data-sh-est-total>KSh 0</p>
				<p class="sh-est__summary" data-sh-est-summary></p>
				<p class="sh-small">An estimate, not a final quote: we confirm the price after seeing your design, vehicle or files. Fitting at our Rabai Road workshop is included for wraps, decals and tints.</p>
			</div>
			<a class="sh-wa-order sh-est__wa" data-sh-est-wa href="<?php echo esc_url( sh_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo SH_WA_ICON; ?>Request custom order via WhatsApp</a>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Quick view pop-up, filled in by sh.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="sh-qv" class="sh-dialog sh-qv" aria-label="Quick view"><form method="dialog"><button class="sh-dialog__close" aria-label="Close">×</button></form><div data-sh-qv-body></div></dialog>';
	echo '<a class="sh-wa-float" href="' . esc_url( sh_wa_link( 'Hi STICKER HUB, I have a design / project idea:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with STICKER HUB on WhatsApp">' . SH_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function sh_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, SH_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / SH_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . sh_money( $left ) . '</strong> more for <strong>free Nairobi express delivery!</strong>'
		: '<strong>You\'ve unlocked free Nairobi express delivery!</strong>';
	return '<div class="sh-freebar" data-sh-freebar>' . $msg . '<div class="sh-freebar__track"><div class="sh-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function sh_cart_note_html() {
	return '<div class="sh-cart-note"><strong>Custom work?</strong> After you order, send your logo or design on WhatsApp. We send a proof before we cut or print.</div>';
}
function sh_wa_cart_html() {
	return '<button type="button" class="sh-wa-cart" data-sh-wa-cart>Send this order to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => sh_freebar_html() . sh_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . sh_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', sh_freebar_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="sh-wa-cart-wrap">' . sh_wa_cart_html() . '</div>' );

// Payment follows delivery: "Pay at the workshop" only for pickup, cash on delivery only for riders and couriers.
add_filter( 'woocommerce_available_payment_gateways', function ( $gateways ) {
	if ( is_admin() && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return $gateways;
	}
	$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods', [] ) : [];
	$pickup = $chosen && array_intersect( $chosen, (array) get_option( 'sh_pickup_rates', [] ) );
	unset( $gateways[ $pickup ? 'cod' : 'cheque' ] );
	return $gateways;
} );

// Once free Nairobi delivery applies, don't also offer the paid rider.
add_filter( 'woocommerce_package_rates', function ( $rates ) {
	$free = array_filter( $rates, fn( $r ) => $r->get_method_id() === 'free_shipping' );
	if ( $free ) {
		$rates = array_filter( $rates, fn( $r ) => ! ( $r->get_method_id() === 'flat_rate' && (float) $r->get_cost() > 0 ) );
	}
	return $rates;
} );

// A retried checkout (customer went back and changed delivery) must replace the old shipping line. WooCommerce
// clears it with a DELETE … USING query that the SQLite database of the Playground demo silently skips, so the
// order kept the old method. Make sure the saved shipping line matches the customer's choice.
add_action( 'woocommerce_store_api_checkout_order_processed', function ( $order ) {
	$chosen = WC()->session ? array_values( (array) WC()->session->get( 'chosen_shipping_methods', [] ) ) : [];
	if ( ! $chosen || ! WC()->cart || ! WC()->cart->needs_shipping() ) {
		return;
	}
	$have = array_values( array_map( fn( $m ) => $m->get_name(), $order->get_shipping_methods() ) );
	$want = [];
	foreach ( WC()->shipping()->get_packages() as $i => $pkg ) {
		if ( isset( $pkg['rates'][ $chosen[ $i ] ?? '' ] ) ) {
			$want[] = $pkg['rates'][ $chosen[ $i ] ]->get_label();
		}
	}
	if ( $want && $have !== $want ) {
		// One item at a time: remove_order_items() is the query the demo's SQLite layer skips.
		foreach ( array_keys( $order->get_shipping_methods() ) as $item_id ) {
			$order->remove_item( $item_id );
		}
		WC()->checkout()->create_order_shipping_lines( $order, $chosen, WC()->shipping()->get_packages() );
		$order->calculate_totals();
		$order->save();
	}
}, 1 );

// A landmark helps the rider find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'sh/landmark',
		'label'    => 'Building, estate or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Order number and WhatsApp summary on the order confirmation page.
function sh_tracking_code( WC_Order $order ) {
	return 'SH-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function sh_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi STICKER HUB, I just placed order ' . sh_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$meta = [];
		foreach ( $item->get_formatted_meta_data() as $m ) {
			$meta[] = wp_strip_all_tags( $m->display_value );
		}
		$lines[] = '• ' . $item->get_name() . ( $meta && ! $item->get_variation_id() ? ' (' . implode( ', ', $meta ) . ')' : '' ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . sh_money( $item->get_total() );
	}
	$lines[] = 'Delivery: ' . $order->get_shipping_method() . ( (float) $order->get_shipping_total() > 0 ? ' (' . sh_money( $order->get_shipping_total() ) . ')' : '' );
	$lines[] = 'Total: ' . sh_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address && stripos( $order->get_shipping_method(), 'pick up' ) === false ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	$lines[] = 'I\'ll send my design / logo here.';
	return sh_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="sh-thanks"><p class="sh-thanks__code">Order number <strong>' . esc_html( sh_tracking_code( $order ) ) . '</strong></p><p>We\'ll call you shortly to confirm. Send your order to our WhatsApp now, with your logo or design files, so we can start on your proof.</p><a class="wp-element-button sh-wa-btn" href="' . esc_attr( sh_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order to WhatsApp (+254 766 386 934)</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( sh_tracking_code( $order ) ) . '</p>';
} );

// Staff edit the badge, durability tag, spec sheet and fitting steps on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_sh_badge', 'label' => 'Category badge', 'description' => 'Shown above the name, e.g. "Automotive Vinyl".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_sh_life', 'label' => 'Durability tag', 'description' => 'e.g. "3–5 yr outdoor rating".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sh_specs', 'label' => 'Specifications', 'rows' => 6, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sh_install', 'label' => 'Surface prep & application', 'rows' => 6, 'description' => 'One step per line.' ] );
	echo '<p class="form-field"><em>Options: add Size (or Pack, Coverage…) and Finish under Attributes, then create a variation for each combination with its price. "Frequently paired together" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_sh_badge', '_sh_life' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
	foreach ( [ '_sh_specs', '_sh_install' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. Buruburu, Westlands, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0D0D0F\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// estimator's and reviews' grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
