( function () {
	const cfg = window.SH || {};
	const freeAt = Number( cfg.freeAt ) || 3000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.sh-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'sh-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'sh-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart · <a href="' + esc( ( cfg.home || '/' ) + 'cart/' ) + '">View cart</a>' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart · <a href="' + esc( ( cfg.home || '/' ) + 'cart/' ) + '">View cart</a>' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
		if ( cart && cart.totals ) renderBar( money( cart.totals.total_items, cart.totals ) );
	}

	// id is the product, or the chosen variation's id.
	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your cart. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sh-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.shAdd, b );
	} );

	/* WhatsApp orders ---------------------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-sh-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi STICKER HUB, I\'d like to order:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) ) );
			lines.push( 'Delivery: pickup at Rabai Road / Nairobi rider / upcountry courier' );
			lines.push( 'My design / logo: (attaching it here)' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Product page: option buttons ------------------------------------- */
	// Turns WooCommerce's option dropdowns into buttons (the dropdowns stay in the form, hidden, so
	// WooCommerce still swaps the photo and price). Colour options get a swatch.
	const SWATCH = { yellow: 'linear-gradient(135deg,#fde68a,#f59e0b)', black: '#111', white: '#f8fafc' };
	const swatchFor = ( text ) => SWATCH[ String( text ).toLowerCase() ] || '';
	function initSwatches() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.shSw ) return;
			sel.dataset.shSw = '1';
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			const swatched = opts.some( ( o ) => swatchFor( o.text ) );
			wrap.className = 'sh-sw' + ( swatched ? '' : ' sh-sw--text' );
			wrap.innerHTML = opts.map( ( o ) => {
				const sw = swatchFor( o.text );
				return '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '">' + ( sw ? '<i style="background:' + sw + '"></i>' : '' ) + '<span>' + esc( o.text ) + '</span></button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'sh-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( sel.closest( 'form' ) );
			} );
			paint();
			updateWaProduct( sel.closest( 'form' ) );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The product page's WhatsApp button names the options the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-sh-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		const msg = 'Hi STICKER HUB, I\'d like the ' + a.dataset.shWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.shWaPrice + ')' ) + '. ' + a.dataset.shWaUrl;
		a.href = waUrl( msg );
	}

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.sh-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'sh-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>Nothing matches “' + esc( q ) + '” yet, but we make custom work every day. <a href="' + esc( waUrl( 'Hi STICKER HUB, can you make: ' + q + '?' ) ) + '">Ask us on WhatsApp</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Free-delivery bar ------------------------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi express delivery!</strong>'
			: "<strong>You've unlocked free Nairobi express delivery!</strong>";
		$$( '[data-sh-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="sh-freebar__track"><div class="sh-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	// The cart page and the mini cart change quantities without a reload; follow them.
	function followCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
		} );
	}

	/* Price calculator ------------------------------------------------- */
	// Prices come from the products themselves (data-calc), so the calculator follows any price change.
	const round2 = ( n ) => Math.round( n * 100 ) / 100;
	function estimate( form ) {
		const calc = JSON.parse( form.dataset.calc || '{}' );
		const f = new FormData( form );
		const type = f.get( 'type' );
		const c = calc[ type ];
		const mat = f.get( 'mat_' + type );
		const num = ( k, min ) => Math.max( min, Number( f.get( k ) ) || 0 );
		const lines = [ 'Material: ' + mat ];
		let qty;
		if ( type === 'print' ) {
			const w = num( 'w', 0.1 );
			const h = num( 'h', 0.1 );
			const n = Math.round( num( 'n', 1 ) );
			qty = w * h * n;
			lines.push( 'Size: ' + w + ' m × ' + h + ' m' + ( n > 1 ? ', ' + n + ' copies' : '' ) + ' = ' + round2( qty ) + ' m²' );
		} else if ( type === 'sticker' ) {
			const w = num( 'sw', 1 );
			const h = num( 'sh', 1 );
			const n = Math.round( num( 'sn', 1 ) );
			qty = ( w * h * n ) / 10000;
			lines.push( n + ' stickers of ' + w + ' × ' + h + ' cm = ' + round2( qty ) + ' m²' );
		} else {
			qty = num( 'm', 0.5 );
			lines.push( 'Length: ' + qty + ' m' );
		}
		const total = Math.ceil( ( ( c.prices[ mat ] || 0 ) * qty ) / 10 ) * 10;
		return { c, total, lines };
	}
	function initEstimator() {
		$$( '[data-sh-estimator]' ).forEach( ( form ) => {
			const out = form.querySelector( '[data-sh-est-total]' );
			const sum = form.querySelector( '[data-sh-est-summary]' );
			const wa = form.querySelector( '[data-sh-est-wa]' );
			const order = form.querySelector( '[data-sh-est-order]' );
			const steps = $$( '.sh-est__steps li', form );
			const update = () => {
				const type = new FormData( form ).get( 'type' );
				$$( '[data-for]', form ).forEach( ( el ) => ( el.hidden = el.dataset.for !== type ) );
				$$( '.sh-est__types label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				const r = estimate( form );
				out.textContent = fmt( r.total );
				sum.textContent = r.c.name + ' · ' + r.lines.join( ' · ' );
				order.href = r.c.url;
				wa.href = waUrl( [ 'Hi STICKER HUB, I\'d like a quote:', '• ' + r.c.name, ...r.lines.map( ( l ) => '• ' + l ), 'Website price: ' + fmt( r.total ), 'Name: ', 'Location: ', '(I\'ll send my design here)' ].join( '\n' ) );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			// Light up the step the customer is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	function init() {
		initSearch();
		initSwatches();
		initEstimator();
		followCart();
		// The product form can re-render client-side; keep the option buttons in place.
		new MutationObserver( () => initSwatches() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
