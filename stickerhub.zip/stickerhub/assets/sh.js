( function () {
	const cfg = window.SH || {};
	const freeAt = Number( cfg.freeAt ) || 3000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.sh-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'sh-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'sh-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart · <a href="' + esc( ( cfg.home || '/' ) + 'cart/' ) + '">View cart</a>' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart · <a href="' + esc( ( cfg.home || '/' ) + 'cart/' ) + '">View cart</a>' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
		if ( cart && cart.totals ) renderBar( money( cart.totals.total_items, cart.totals ) );
	}

	// id is the product, or the chosen variation's id.
	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your cart. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sh-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.shAdd, b );
	} );

	/* WhatsApp orders ---------------------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-sh-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi STICKER HUB, I\'d like to order:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) ) );
			lines.push( 'Delivery: pickup at Rabai Road / Nairobi rider / upcountry courier' );
			lines.push( 'My design / logo: (attaching it here)' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Product page: option buttons ------------------------------------- */
	// Turns WooCommerce's option dropdowns into buttons (the dropdowns stay in the form, hidden, so
	// WooCommerce still swaps the photo and price). Finish options get a material swatch.
	const FINISH = {
		gloss: 'linear-gradient(135deg,#ffffff 0%,#cbd5e1 45%,#ffffff 55%,#94a3b8 100%)',
		matte: '#4b5563',
		reflective: 'repeating-linear-gradient(45deg,#e2e8f0 0 3px,#94a3b8 3px 6px)',
		holographic: 'conic-gradient(from 30deg,#f472b6,#fbbf24,#34d399,#60a5fa,#a78bfa,#f472b6)',
		'carbon-fibre': 'repeating-linear-gradient(45deg,#111 0 3px,#2d2d33 3px 6px)',
		chameleon: 'linear-gradient(135deg,#22c55e,#eab308 50%,#a855f7)',
		smoked: 'linear-gradient(135deg,#52525b,#09090b)',
	};
	const SHADE = { 'light smoke': FINISH.smoked, 'dark smoke': '#18181b', yellow: 'linear-gradient(135deg,#fde68a,#f59e0b)', black: '#111', white: '#f8fafc' };
	const swatchFor = ( name, value, text ) => {
		if ( name === 'attribute_pa_finish' ) return FINISH[ value ] || '#444';
		return SHADE[ String( text ).toLowerCase() ] || '';
	};
	function initSwatches() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.shSw ) return;
			sel.dataset.shSw = '1';
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			const swatched = opts.some( ( o ) => swatchFor( sel.name, o.value, o.text ) );
			wrap.className = 'sh-sw' + ( swatched ? '' : ' sh-sw--text' );
			wrap.innerHTML = opts.map( ( o ) => {
				const sw = swatchFor( sel.name, o.value, o.text );
				return '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '">' + ( sw ? '<i style="background:' + sw + '"></i>' : '' ) + '<span>' + esc( o.text ) + '</span></button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'sh-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( sel.closest( 'form' ) );
			} );
			paint();
			updateWaProduct( sel.closest( 'form' ) );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The product page's WhatsApp button names the options the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-sh-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		const msg = 'Hi STICKER HUB, I\'d like the ' + a.dataset.shWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.shWaPrice + ')' ) + '. ' + a.dataset.shWaUrl;
		a.href = waUrl( msg );
	}

	/* Wishlist ----------------------------------------------------------- */
	const KEY = 'sh-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-sh-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.shWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-sh-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sh-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.shWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to <a href="' + esc( cfg.home || '/' ) + 'wishlist/">your wishlist</a>' );
		if ( b.closest( '[data-sh-wishlist]' ) ) renderWishlist();
	} );

	// Add button for a product: products with options link to the product page to choose them.
	const choiceNames = ( p ) => ( p.attributes || [] ).filter( ( a ) => a.has_variations ).map( ( a ) => plain( a.name ).toLowerCase() );
	const buyButton = ( p ) => {
		if ( ! p.is_purchasable || ! p.is_in_stock ) return '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View</a>';
		if ( p.type === 'variable' ) {
			return '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p ).slice( 0, 2 ).join( ' & ' ) || 'options' ) + '</a>';
		}
		return '<button type="button" class="wp-element-button" data-sh-add="' + p.id + '">Add to cart</button>';
	};

	async function renderWishlist() {
		const box = document.querySelector( '[data-sh-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="sh-empty"><p>Nothing saved yet. Tap the ♥ on any decal, wrap or print to keep it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse decals & services</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="sh-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="sh-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="sh-heart is-on" data-sh-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="sh-wish-price">' + p.price_html + '</div>' + buyButton( p ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your saved items. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	// Variations are listed as buttons ("Medium · Matte") when there are few; otherwise the
	// customer chooses on the product page.
	const QV_MAX = 8;
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-sh-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'sh-qv' );
		const body = dlg && dlg.querySelector( '[data-sh-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="sh-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.shQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '" data-img-id="' + im.id + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="sh-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-sh-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cats = p.categories && p.categories[ 0 ] ? plain( p.categories[ 0 ].name ) : '';
			const finishes = ( p.attributes || [] ).find( ( a ) => a.taxonomy === 'pa_finish' );
			const finishLine = finishes ? '<p class="sh-qv__fin">' + finishes.terms.map( ( t ) => '<span><i style="background:' + ( FINISH[ t.slug ] || '#444' ) + '"></i>' + esc( plain( t.name ) ) + '</span>' ).join( '' ) + '</p>' : '';
			let choose = '';
			let buy;
			const termName = ( attrName, val ) => {
				const attr = ( p.attributes || [] ).find( ( a ) => a.name === attrName || a.taxonomy === attrName );
				const term = attr && ( attr.terms || [] ).find( ( t ) => t.slug === val || t.name === val );
				return term ? plain( term.name ) : val;
			};
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<span class="sh-badge sh-badge--out">Out of stock</span>';
			} else if ( p.variations && p.variations.length && p.variations.length <= QV_MAX ) {
				choose = '<p class="sh-qv__label">' + esc( choiceNames( p ).join( ' & ' ) ) + ': <strong data-sh-qv-picked></strong></p><div class="sh-sw sh-sw--text">' + p.variations.map( ( v, i ) => {
					const label = ( v.attributes || [] ).map( ( a ) => termName( a.name, a.value ) ).join( ' · ' );
					return '<button type="button" data-sh-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '><span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-sh-add="' + p.variations[ 0 ].id + '" data-sh-qv-buy>Add to cart</button>';
			} else if ( p.type === 'variable' ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p ).slice( 0, 2 ).join( ' & ' ) ) + '</a>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-sh-add="' + p.id + '">Add to cart</button>';
			}
			body.innerHTML = '<div class="sh-qv__grid"><div class="sh-qv__media"><div class="sh-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="sh-qv__info">' + ( cats ? '<p class="sh-eyebrow">' + esc( cats ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="sh-qv__price">' + p.price_html + '</div>' + finishLine +
				'<div class="sh-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="sh-qv__actions">' + buy + '<a class="sh-link" href="' + esc( p.permalink ) + '">Spec sheet & details →</a></div></div></div>';
			const first = body.querySelector( '[data-sh-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this item. Please try again.</p>';
		}
	} );
	// Variation photo and price: the Store API lists variations without them, so fetch the chosen one.
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-sh-qv-body]' );
		$$( '[data-sh-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-sh-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-sh-qv-buy]' );
		if ( buy ) buy.dataset.shAdd = btn.dataset.shQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.shQvVar ) ).json();
			// A slower reply for an earlier pick must not overwrite the current one.
			if ( ! btn.classList.contains( 'is-on' ) ) return;
			const price = box.querySelector( '.sh-qv__price' );
			if ( price && v.price_html ) price.innerHTML = v.price_html;
			const img = v.images && v.images[ 0 ];
			if ( img ) {
				const main = $$( '.sh-qv__main img', box );
				const hit = main.findIndex( ( im ) => Number( im.dataset.imgId ) === img.id );
				if ( hit > -1 ) main.forEach( ( im, i ) => ( im.hidden = i !== hit ) );
			}
			if ( buy ) {
				buy.disabled = ! v.is_in_stock;
				buy.textContent = v.is_in_stock ? 'Add to cart' : 'Out of stock';
			}
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sh-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-sh-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.sh-qv__media' ).querySelectorAll( '.sh-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.shQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.sh-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.sh-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'sh-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>Nothing matches “' + esc( q ) + '” yet, but we make custom work every day. <a href="' + esc( waUrl( 'Hi STICKER HUB, can you make: ' + q + '?' ) ) + '">Ask us on WhatsApp</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Free-delivery bar ------------------------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi express delivery!</strong>'
			: "<strong>You've unlocked free Nairobi express delivery!</strong>";
		$$( '[data-sh-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="sh-freebar__track"><div class="sh-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	// The cart page and the mini cart change quantities without a reload; follow them.
	function followCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
		} );
	}

	/* Cost estimator ----------------------------------------------------- */
	const TYPE_NAMES = { wrap: 'Vehicle wrap', decal: 'Custom decal', tint: 'Headlight tint', tshirt: 'T-shirt batch' };
	const FIN_NAMES = { gloss: 'Standard gloss', matte: 'Matte', reflective: 'Reflective', 'carbon-fibre': 'Carbon fibre', chameleon: 'Chameleon', holographic: 'Holographic' };
	const tier = ( table, n ) => {
		let v = 0;
		Object.keys( table ).map( Number ).sort( ( a, b ) => a - b ).forEach( ( from ) => {
			if ( n >= from ) v = table[ from ];
		} );
		return v;
	};
	function estimate( form ) {
		const est = cfg.est;
		const f = new FormData( form );
		const type = f.get( 'type' );
		const num = ( k, min ) => Math.max( min, Math.round( Number( f.get( k ) ) || 0 ) );
		const visible = ( sel ) => form.querySelector( sel + ':not([hidden])' );
		const finishIn = ( box ) => {
			const r = box && box.querySelector( 'input[type=radio]:checked' );
			return r ? r.value : '';
		};
		const lines = [];
		let total = 0;
		if ( type === 'wrap' ) {
			const v = f.get( 'vehicle' );
			const a = f.get( 'area' );
			const fin = finishIn( visible( '.sh-est__fins[data-for="wrap"]' ) );
			total = est.wrap.areas[ a ][ 1 ][ v ] * ( est.wrap.finishes[ fin ] || 1 );
			lines.push( 'Vehicle: ' + est.wrap.vehicles[ v ], 'Coverage: ' + est.wrap.areas[ a ][ 0 ], 'Finish: ' + FIN_NAMES[ fin ] );
		} else if ( type === 'decal' ) {
			const w = num( 'w', 5 );
			const h = num( 'h', 5 );
			const q = num( 'qty', 1 );
			const fin = finishIn( visible( '.sh-est__fins[data-for="decal"]' ) );
			const each = Math.max( est.decal.min, ( w * h / 10000 ) * est.decal.per_m2 * ( est.decal.finishes[ fin ] || 1 ) );
			const off = tier( est.decal.bulk, q );
			total = each * q * ( 1 - off );
			lines.push( 'Size: ' + w + ' × ' + h + ' cm', 'Quantity: ' + q + ( off ? ' (' + Math.round( off * 100 ) + '% bulk discount)' : '' ), 'Finish: ' + FIN_NAMES[ fin ] );
		} else if ( type === 'tint' ) {
			const l = f.get( 'lights' );
			const s = f.get( 'shade' );
			total = est.tint.lights[ l ][ 1 ];
			lines.push( 'Lights: ' + est.tint.lights[ l ][ 0 ], 'Shade: ' + est.tint.shades[ s ] );
		} else if ( type === 'tshirt' ) {
			const n = num( 'shirts', 1 );
			const both = f.get( 'sides' ) === 'both';
			const each = tier( est.tshirt.tiers, n ) + ( both ? tier( est.tshirt.back, n ) : 0 );
			total = each * n;
			lines.push( 'Shirts: ' + n + ' (' + fmt( each ) + ' each)', 'Print: ' + ( both ? 'Front + back' : 'Front only' ), 'Shirt colour: ' + f.get( 'tee' ) );
		}
		total = Math.round( total / 50 ) * 50;
		return { type, total, lines };
	}
	function initEstimator() {
		$$( '[data-sh-estimator]' ).forEach( ( form ) => {
			const out = form.querySelector( '[data-sh-est-total]' );
			const sum = form.querySelector( '[data-sh-est-summary]' );
			const wa = form.querySelector( '[data-sh-est-wa]' );
			const steps = $$( '.sh-est__steps li', form );
			const update = () => {
				const type = new FormData( form ).get( 'type' );
				$$( '[data-for]', form ).forEach( ( el ) => ( el.hidden = el.dataset.for !== type ) );
				$$( '.sh-est__types label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				$$( '.sh-fin', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				const r = estimate( form );
				out.textContent = fmt( r.total );
				sum.textContent = TYPE_NAMES[ r.type ] + ' · ' + r.lines.join( ' · ' );
				wa.href = waUrl( [ 'Hi STICKER HUB, I\'d like a quote for a custom order:', '• Project: ' + TYPE_NAMES[ r.type ], ...r.lines.map( ( l ) => '• ' + l ), 'Website estimate: ' + fmt( r.total ), 'Name: ', 'Location: ', '(I\'ll send my design / photos here)' ].join( '\n' ) );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			// Light up the step the customer is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		initSwatches();
		initEstimator();
		followCart();
		// Cards and the mini cart re-render client-side; keep hearts and swatches in sync.
		new MutationObserver( () => {
			paintWish();
			initSwatches();
		} ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
